# ChatGPT prompt (EN): SHE "All together" gift box — 27.11
Attach: reference obrazcy/obrazec_6.webp (pink box with bow on the lid) + product images 5, 6 (3d), 3, 4.

Create a photorealistic product photo of a gift box for an online shop, in the style of the attached reference photo (pink rigid gift box with the lid open, satin ribbon bow on the lid).

The box: a rectangular rigid cardboard box, light pink outside (#F4C3D2), magnetic lid opened and standing upright behind it. Across the lid, a pink satin ribbon with a neat bow and a small gold bead in the center. A short pink ribbon pull tab sticks out at the front center. The inside walls and bottom are lined with paper printed with small stars: light pink background (#F9DDE6), stars in pink (#E79AB4), dark pink (#C2668A) and white. Camera looks at the box from above and slightly in front, about 45 degrees.

Inside the box, neatly and snugly arranged like a real gift set, lie the items from the attached images. Copy their design, text and artwork exactly — do not redraw or change them:
1. The "Язык эмоций" card deck box (image 5) — lying flat, front side up, its thickness visible.
2. The "Тайный сад" card deck box (image 6) — lying flat next to it.
3. The "Мой идеальный планер 2027" planner cover (image 3) — a thick flat card, lying flat.
4. The SHE journal (image 4) — a pink hardcover book lying flat, light page edges visible.

A little pink shredded paper between the items. Soft warm daylight, soft shadows. Plain light background, no other objects, no people, no added text. Square image, box centered and filling most of the frame. Keep all lettering on the deck boxes, planner and journal exactly as in the images.
